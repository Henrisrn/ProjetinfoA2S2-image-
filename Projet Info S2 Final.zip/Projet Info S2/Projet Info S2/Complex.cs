﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_Info_S2
{
    class Complexe
    {
        ///Cette classe permet de crée la classe des complexes et de définir les différents calculs entre plusieurs complexe
        ///Elle est issus de la bibliothèque Math.Complexe
        ///Elle est utilisé uniquement pour faire des fractales
        private double reel;
        private double image;
        public Complexe(double reel,double image)
        {
            this.reel = reel;
            this.image = image;
        }
        public double Image
        {
            get { return image; }
            set { this.image = value;}
        }
        public double Reel
        {
            get { return reel; }
            set { this.reel = value; }
        }
        public double Modulo()
        {
            return Math.Sqrt(Math.Pow(reel, 2) + Math.Pow(image, 2));
        }
        public static Complexe operator + (Complexe a,Complexe b)
        {
            return new Complexe(b.Reel + a.Reel, a.Image + b.Image);
        }
        public static Complexe operator * (Complexe a,Complexe b)
        {
            return new Complexe(b.Reel * a.Reel - b.Image * a.Image, b.Image * a.Reel + b.Reel * a.Image);
        }


    }
}
