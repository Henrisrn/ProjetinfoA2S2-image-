﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_Info_S2
{
    class QRcode
    {
        public byte[] indicateur = { 0, 0, 1, 0 };
        private byte[] longmot;
        private byte[] message;
        private int version;
        private int codeversion;
        private int hauteur;
        private int nbbiteaccepté;
        private int largeur;
        //Ecriture/Création d'un QR code
        public QRcode(string nom)
        {
            //ENCODAGE

            nom = nom.ToUpper();
            if(nom.Length >= 10 && nom.Length <= 25)
            {
                version = 1;
                codeversion = 7;
                hauteur = largeur = 21;
                nbbiteaccepté = 152;
            }
            else if (nom.Length >= 26 && nom.Length <= 47)
            {
                version = 2;
                codeversion = 10;
                hauteur = largeur = 25;
                nbbiteaccepté = 272;
            }
            else if (nom.Length >= 48 && nom.Length <= 77)
            {
                version = 3;
                codeversion = 15;
                hauteur = largeur = 29;
                nbbiteaccepté = 392;
            }
            else if (nom.Length >= 78 && nom.Length <= 114)
            {
                version = 4;
                codeversion = 20;
                hauteur = largeur = 33;
                nbbiteaccepté = 512;
            }
           
            
            longmot = InttoByte(nom.Length, 9);
            
            message = ChartoBin(nom);
            //Console.WriteLine("Nom en byte : " + AfficherTab(message) + " Longueur du message en byte : " + message.Length);
            List<byte> complet = new List<byte>();
            
            Pixel[,] Qr = new Pixel[hauteur, largeur];
            AjouterListTab(complet, indicateur);
            AjouterListTab(complet, longmot);
            AjouterListTab(complet, message);
            if (complet.Count < nbbiteaccepté) //Pour un encodeur 1-L
            {
                if ((152 - complet.Count) >= 4) {
                    for (int i = 0; i < 4; i++)
                    {
                        complet.Add(0);
                    }
                }
                else
                {
                    for (int i = 0; i < (nbbiteaccepté - complet.Count); i++)
                    {
                        complet.Add(0);
                    }
                }
            }
            while (complet.Count % 8 != 0)
            {
                complet.Add(0);
            }
            byte[] p = { 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1 };
            byte[] g = { 1, 1, 1, 0, 1, 1, 0, 0 };
            if (complet.Count < nbbiteaccepté)
            {
                int nbmotif = (nbbiteaccepté - complet.Count) / 8;
                int nbfois = nbmotif / 2;
                if (nbmotif % 2 == 0)
                {
                    for (int i = 0; i < nbfois; i++)
                    {
                        AjouterListTab(complet, p);
                    }
                }
                else
                {
                    decimal a = Math.Truncate(Convert.ToDecimal(nbfois));
                    for (int i = 0; i < a; i++)
                    {
                        AjouterListTab(complet, p);
                    }
                    AjouterListTab(complet, g);
                }
                //Console.WriteLine("Le message complet est : ");
                //AfficherList(complet);
                //Console.WriteLine("La longueur actuel du message est : " + complet.Count);
                //Console.WriteLine("Passe au validateur : " + Validateur(complet));
                //VOIR COMMENT ON S'ORGANISE POUR LE CORRECTEUR
                //209 239 196 207 78 195 109

                //ALGO DE REED SALOMON
                
                
               
                List<byte> ConversionHexa = new List<byte>();
                byte[] bytesa = FromListToTab(complet);
                for (int i = 0; i < bytesa.Length; i+=8)
                {
                    byte[] tab3 = new byte[8];
                    for(int j = 0;j<8;j++)
                    {
                        tab3[j] = bytesa[i+j];
                    }
                    ConversionHexa.Add((byte)FromBintoInt(tab3,0,8));
                    
                }
                Encoding u8 = Encoding.UTF8;
                
                int iBC = u8.GetByteCount(nom);
                byte[] bytesaa = u8.GetBytes(nom);
                //AfficherList(ConversionHexa);
                
                //byte[] result = ReedSolomonAlgorithm.Encode(bytesa, 7);
                //Privilégiez l'écriture suivante car par défaut le type choisi est DataMatrix 
                byte[] result3 = ReedSolomonAlgorithm1.Encode(FromListToTab(ConversionHexa), codeversion, ErrorCorrectionCodeType.QRCode);
                //byte[] result1 = ReedSolomonAlgorithm.Decode(bytesb, result);
                
                for(int i = 0;i<result3.Length;i++)
                {
                    AjouterListTab(complet, InttoByte(result3[i], 8));
                    //Console.WriteLine(" i = "+i+"  ==  "+result3[i]);
                }
                //209 239 196 207 78 195 109 POUR HELLO WORLD (voir après comment faire pour gérer le problème
                if(version > 1)
                {
                    //CENTRALE
                    Qr[Qr.GetLength(0) - 7,Qr.GetLength(1)-7] = new Pixel(0,0,0);
                    //CONTOUR BLANC
                    for(int i = 0;i<3;i++)
                    {
                        Qr[Qr.GetLength(0) - 6-i, Qr.GetLength(0) - 6] = new Pixel(255, 255, 255);
                        Qr[Qr.GetLength(0) - 6, Qr.GetLength(0) - 6-i] = new Pixel(255, 255, 255);
                        Qr[Qr.GetLength(0) - 8+i, Qr.GetLength(0) - 8] = new Pixel(255, 255, 255);
                        Qr[Qr.GetLength(0) - 8, Qr.GetLength(0) - 8+i] = new Pixel(255, 255, 255);
                    }
                    for (int i = 0; i < 5; i++)
                    {
                        Qr[Qr.GetLength(0) - 5 - i, Qr.GetLength(0) - 5] = new Pixel(0, 0, 0);
                        Qr[Qr.GetLength(0) - 5, Qr.GetLength(0) - 5 - i] = new Pixel(0, 0, 0);
                        Qr[Qr.GetLength(0) - 9 + i, Qr.GetLength(0) - 9] = new Pixel(0, 0, 0);
                        Qr[Qr.GetLength(0) - 9, Qr.GetLength(0) - 9 + i] = new Pixel(0, 0, 0);
                    }


                }







                //RESTE PROVISOIRE MAIS BONN ON VERRA POUR LE RESTE
                //Déjà la lettre c'est L toujours
                //111011111000100 
                Pixel[,] motif = MotifCoin(7, 7);
                for (int i = 0; i < motif.GetLength(0); i++)
                {
                    for (int j = 0; j < motif.GetLength(1); j++)
                    {
                        Qr[i, j] = motif[i, j];
                        Qr[Qr.GetLength(0) - 1 - i, j] = motif[i, j];
                        Qr[i, Qr.GetLength(1) - 1 - j] = motif[i, j];
                    }
                    Qr[motif.GetLength(0), i] = new Pixel(255, 255, 255);
                    Qr[motif.GetLength(0), Qr.GetLength(0) - 1 - i] = new Pixel(255, 255, 255);
                    Qr[Qr.GetLength(0) - 1 - motif.GetLength(0), i] = new Pixel(255, 255, 255);
                    Qr[i, motif.GetLength(1)] = new Pixel(255, 255, 255);
                    Qr[Qr.GetLength(1) - 1 - i, motif.GetLength(1)] = new Pixel(255, 255, 255);
                    Qr[i, Qr.GetLength(1) - 1 - motif.GetLength(1)] = new Pixel(255, 255, 255);
                }
                int separateurX = hauteur - 2 * motif.GetLength(0) - 1;
                int separateurY = largeur - 2 * motif.GetLength(1) - 1;
                for (int i = 0; i < separateurX; i += 2)
                {
                    //Pour le separateur en X
                    Qr[motif.GetLength(0) + 1 + i, motif.GetLength(1) - 1] = new Pixel(0, 0, 0);
                    Qr[motif.GetLength(0) + 2 + i, motif.GetLength(1) - 1] = new Pixel(255, 255, 255);
                    //Pour le separateur en Y
                    Qr[motif.GetLength(1) - 1, motif.GetLength(0) + 1 + i] = new Pixel(0, 0, 0);
                    Qr[motif.GetLength(1) - 1, motif.GetLength(0) + 2 + i] = new Pixel(255, 255, 255);
                }
                Qr[motif.GetLength(0), motif.GetLength(1)] = new Pixel(255, 255, 255);
                Qr[Qr.GetLength(0) - motif.GetLength(0) - 1, motif.GetLength(1)] = new Pixel(255, 255, 255);
                Qr[motif.GetLength(0), Qr.GetLength(1) - motif.GetLength(1) - 1] = new Pixel(255, 255, 255);
                Qr[motif.GetLength(0) + 1, Qr.GetLength(1) - motif.GetLength(1) - 1] = new Pixel(0, 0, 0);
                //Masque 111011111000100 
                byte[] masque = new byte[] { 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0 };
                Pixel[] masquePix = FromBytetoPixel(FromTabToList(masque));
                //MIEUX PLACER LE MASQUE
                //On mets 4 boucle for pour remplir le masque
                int o = 0;
                int h = motif.GetLength(1) + 1;
                //ReedSolomon a = new ReedSolomon();
                for (int i = 0; i < 8; i++)
                {
                    if (Qr[i, h] == null)
                    {
                        Qr[i, h] = masquePix[o];
                        o++;
                    }
                }
                for (int i = 0; i <=8; i++)
                {
                    if (Qr[8, 8-i] == null)
                    {
                        Qr[8, 8-i] = masquePix[o];
                        o++;
                    }
                }
                o = 0;
                h = motif.GetLength(1) + 1;
                for (int i = Qr.GetLength(1) - 1; i > Qr.GetLength(1) - 8; i--)
                {
                    if (Qr[h, i] == null)
                    {
                        Qr[h, i] = masquePix[o];
                        o++;
                    }
                }
                for (int i = 8; i >0; i--)
                {

                    if (Qr[Qr.GetLength(0)-i, 8] == null)
                    {
                        Qr[Qr.GetLength(0) - i, 8] = masquePix[o];
                        o++;
                    }
                    
                }
                //Console.WriteLine("Traduction en hexa");
                //Console.WriteLine(AfficherTab(FromBintoByte(complet)));
                //Encodage
                int cpt = 0;
                Pixel[] complet4 = FromBytetoPixel(complet);
                for (int i = Qr.GetLength(0) - 1; i >= 0; i -= 4)
                {
                    for (int j = Qr.GetLength(1) - 1; j >= 0; j--)
                    {
                        if (Qr[i, j] == null && complet4.Length > cpt)
                        {
                            Qr[i, j] = complet4[cpt];
                            cpt++;
                            if ((i + j) % 2 == 0)
                            {
                                if(Qr[i , j].R == 255)
                                {
                                    Qr[i, j] = new Pixel(0, 0, 0);
                                }
                                else
                                {
                                    Qr[i, j] = new Pixel(255, 255, 255);
                                }
                            }
                        }
                        if (i != 0 && Qr[i - 1, j] == null && complet4.Length > cpt)
                        {
                            Qr[i - 1, j] = complet4[cpt];
                            cpt++;
                            if ((i + j - 1) % 2 == 0)
                            {
                                if (Qr[i - 1, j].R == 255)
                                {
                                    Qr[i-1, j] = new Pixel(0, 0, 0);
                                }
                                else
                                {
                                    Qr[i-1, j] = new Pixel(255, 255, 255);
                                }
                            }
                        }
                    }
                    //DESCENTE
                    for (int j = 0; j < Qr.GetLength(1); j++)
                    {
                        if (i != 0 && Qr[i - 2, j] == null && complet4.Length > cpt)
                        {
                            Qr[i - 2, j] = complet4[cpt];
                            cpt++;
                            if ((i + j - 2) % 2 == 0)
                            {
                                if (Qr[i - 2, j].R == 255)
                                {
                                    Qr[i-2, j] = new Pixel(0, 0, 0);
                                }
                                else
                                {
                                    Qr[i-2, j] = new Pixel(255, 255, 255);
                                }
                            }
                        }
                       
                        if (i != 0 && Qr[i - 3, j] == null && complet4.Length > cpt)
                        {
                            Qr[i -3, j] = complet4[cpt];
                            cpt++;
                            if ((i + j - 3) % 2 == 0)
                            {
                                if (Qr[i-3, j].R == 255)
                                {
                                    Qr[i-3, j] = new Pixel(0, 0, 0);
                                }
                                else
                                {
                                    Qr[i-3, j] = new Pixel(255, 255, 255);
                                }
                            }
                        }
                    }
                }
                //AfficherList(complet);
                Console.WriteLine("Qr Code crée avec succés");
                Export(Qr, "res.bmp");
            }
        }
        //Lecture d'un Qr code
        public QRcode(Myimage image)
        {
            Pixel[,] mat = image.Matrice;
            
            //Normalement il faut que l'on regarde si le Qr code est dans le bon sens
            //On récupère la taille des motifs de lecture du QrCode
            int taillemoti = 0;
            
            int[] a = new int[4];
            //Myimage.AfficherImage(mat);
            //On cherche le début du Qrcode
            if (mat[0, 0].R != 0)
            {
                a = DebutImage(mat);
            }
            else
            {
                a = new int[] { 0, 0, 0, 0 };
            }
            int xdebut = a[0];
            int ydebut = a[1];
            int xfin = a[2];
            int yfin = a[3];
            Pixel[,] Qrcode2 = new Pixel[xfin - xdebut + 1, yfin - ydebut + 2];
            //On fait une deuxième image avec juste le Qr code sans les contours

            if(Qrcode2.GetLength(0) == 25)
            {
                version = 2;
                Pixel[,] Qr = Qrcode2;
                Qr[Qr.GetLength(0) - 7, Qr.GetLength(1) - 7] = new Pixel(0, 0, 0);
                //CONTOUR BLANC
                for (int i = 0; i < 3; i++)
                {
                    Qr[Qr.GetLength(0) - 6 - i, Qr.GetLength(0) - 6] = null;
                    Qr[Qr.GetLength(0) - 6, Qr.GetLength(0) - 6 - i] = null;
                    Qr[Qr.GetLength(0) - 8 + i, Qr.GetLength(0) - 8] = null;
                    Qr[Qr.GetLength(0) - 8, Qr.GetLength(0) - 8 + i] = null;
                }
                for (int i = 0; i < 5; i++)
                {
                    Qr[Qr.GetLength(0) - 5 - i, Qr.GetLength(0) - 5] = null;
                    Qr[Qr.GetLength(0) - 5, Qr.GetLength(0) - 5 - i] = null;
                    Qr[Qr.GetLength(0) - 9 + i, Qr.GetLength(0) - 9] = null;
                    Qr[Qr.GetLength(0) - 9, Qr.GetLength(0) - 9 + i] = null;
                }
                codeversion = 10;
            }
            //On recupère la version
            else if(Qrcode2.GetLength(0) == 21)
            {
                version = 1;
                codeversion = 7;
            }
            for (int i = xdebut; i <= xfin; i++)
            {
                for (int j = ydebut; j <= yfin + 1; j++)
                {
                    Qrcode2[i - xdebut, j - ydebut] = mat[i, j];
                }
            }
            while (xdebut < mat.GetLength(0) && mat[xdebut, ydebut].R == 0)
            {
                taillemoti++;
                xdebut++;
            }
            //Console.WriteLine("La taille du motif fait : " + taillemoti);
            //On enlève le motif de la matrice
            //ATTENTION PRENDRE EN COMPTE LE MASQUE QUI EST CODEE SUR LES EXTREMITER
            for (int i = 0; i < taillemoti + 1; i++)
            {
                for (int j = 0; j < taillemoti +1; j++)
                {
                    Qrcode2[i, j] = null;
                    Qrcode2[Qrcode2.GetLength(0) - 1 - i, j] = null;
                    Qrcode2[i, Qrcode2.GetLength(1) - 1 - j] = null;
                }
            }
            //RECUPERATION DU FILTRE
            List<Pixel> Masque = new List<Pixel>();
            int h = taillemoti + 1;
            for (int i = 0; i < 8; i++)
            {
                    Masque.Add(Qrcode2[i, h]);
                    Qrcode2[h, Qrcode2.GetLength(1)-8+i] = null;
                    Qrcode2[i, h] = null;
            }
            for (int i = 0; i <= 8; i++)
            {         
                    Masque.Add(Qrcode2[8, 8 - i]);
                    Qrcode2[8, 8 - i] = null;
                    Qrcode2[Qrcode2.GetLength(0)-1 - i, 8] = null;
            }
            //AfficherList(FromPixtoByte(Masque));
            //Console.WriteLine(Masque.Count());
            //Myimage.AfficherImage(Qrcode2);
            //On enlève les séparateurs
            for(int i = 0;i<Qrcode2.GetLength(0);i++)
            {
                Qrcode2[taillemoti, i] = null;
                Qrcode2[i, taillemoti] = null;
            }
            //Myimage.AfficherImage(Qrcode2);
            List<Pixel> décode = new List<Pixel>();
            //Console.WriteLine("Le motif fait " + taillemoti + " comme taille");
            mat = Qrcode2;
            List<Pixel> mes = new List<Pixel>();
            
            for (int i = Qrcode2.GetLength(0)-1; i > 0; i -= 4)
            {
                //Lecture en monté
                for (int j = Qrcode2.GetLength(0)-1 ; j > 0; j--)
                {
                    if (mat[i, j] != null)
                    {
                        if ((i + j) % 2 == 0)
                        {
                            if (Qrcode2[i , j].R == 255)
                            {
                                Qrcode2[i, j] = new Pixel(0, 0, 0);
                            }
                            
                            else
                            {
                                Qrcode2[i, j] = new Pixel(255, 255, 255);
                            }
                        }
                        mes.Add(Qrcode2[i, j]);
                        //Console.WriteLine("Case i = " + i + " j = " + j + " Numéro rajouté "+mat[i,j].R);
                    }
                    if (Qrcode2[i-1, j] != null)
                    {
                        if ((i -1 + j ) % 2 == 0)
                        {
                            if (Qrcode2[i - 1, j].R == 255)
                            {
                                Qrcode2[i - 1, j] = new Pixel(0, 0, 0);
                            }
                            else
                            {
                                Qrcode2[i - 1, j] = new Pixel(255, 255, 255);
                            }
                        }
                        mes.Add(Qrcode2[i-1, j]);
                        //Console.WriteLine("Case i = " + (i-1) + " j = " + j+" Numéro rajouté " + Qrcode2[i-1, j].R);
                    }
                }
                //Lecture en descente
                for (int j = 0; j < Qrcode2.GetLength(0); j++)
                {
                    if (Qrcode2[i - 2, j] != null)
                    {
                        if ((i + j-2) % 2 == 0)
                        {
                            if (Qrcode2[i-2, j].R == 255)
                            {
                                Qrcode2[i-2, j] = new Pixel(0, 0, 0);
                            }
                            else
                            {
                                Qrcode2[i-2, j] = new Pixel(255, 255, 255);
                            }
                        }
                        mes.Add(Qrcode2[i - 2, j]);
                        //Console.WriteLine("Case i = " + (i-3) + " j = " + j + " Numéro rajouté " + Qrcode2[i-3, j].R);
                    }
                    if (Qrcode2[i - 3, j] != null)
                    {
                        if ((i + j-3) % 2 == 0)
                        {
                            if (Qrcode2[i - 3, j].R == 255)
                            {
                                Qrcode2[i-3, j] = new Pixel(0, 0, 0);
                            }
                            else
                            {
                                Qrcode2[i-3, j] = new Pixel(255, 255, 255);
                            }
                        }
                        mes.Add(Qrcode2[i - 3, j]);
                        //Console.WriteLine("Case i = " + (i-2) + " j = " + j + " Numéro rajouté " + Qrcode2[i-2, j].R);
                    }
                }
            }
            List<byte> message = new List<byte>();
            for (int i = 0; i < mes.Count(); i++)
            {
                if (mes.ElementAt(i).R == 0) { message.Add(1); }
                else { message.Add(0); }
            }
            //Console.WriteLine(" LISTE DE BYTE DECODER ");
            //AfficherList(message);

            //Extraire ReedSalomon
            /*
            List<byte> SortieSalomon = new List<byte>();
            List<byte> Result = new List<byte>();
            for (int j = 0; j < codeversion; j++)
            {
                for (int i = 0; i <8; i++)
                {
                    SortieSalomon.Add(message.ElementAt(message.Count-1 - i));
                }
                
                Result.Add((byte)FromBintoInt(FromListToTab(SortieSalomon), 0, 8));
                
            }
            
            byte[] result1 = ReedSolomonAlgorithm1.Decode(FromBinToHexa(FromListToTab(message)), FromListToTab(Result), ErrorCorrectionCodeType.QRCode);
            
            
            for(int i = 0;i<result1.Length;i++)
            {
                Console.Write(result1[i] + " ");
            }*/
            EnleverBitList(message, 0, 4);
            int taille = FromBintoInt(FromListToTab(message), 0, 9);
            Console.WriteLine("La taille du message est de : " + taille);
            Console.WriteLine("Le mot décripté en brut : "+FromBintoString(FromListToTab(message), taille));

            //Myimage.AfficherImage(Qrcode2);
            //EXPORT DE TEST
            

        }
        
        //Permet de faire des traduction à partir d'un tableau en binaire
        public byte[] FromBinToHexa(byte[]tab)
        {
            byte[] res = new byte[tab.Length/8];
            byte[] inter = new byte[8];
            for(int i = 0;i<tab.Length/8;i++)
            {
                for(int j = 0;j<8;j++)
                {
                    inter[j] = tab[i];
                }
                res[i] = (byte)(FromBintoInt(inter, 0, 8));
            }
            return res;
        }
        public string FromBintoString(byte[] tab, int taille)
        {
            string res = null;
            List<byte> nom = new List<byte>();
            int cpt = 0;
            if (taille % 2 == 0)
            {
                int coupleLettre, lettre1, lettre2;
                for (int i = 0; i < (taille / 2); i++)
                {
                    
                    for (int j = 0; j < 11; j++)
                    {
                        nom.Add(tab[j + 9 + cpt]);
                    }
                    cpt += 11;
                    
                    //AfficherList(nom);
                    coupleLettre = FromBintoInt(FromListToTab(nom), 0, 11);
                    
                    lettre2 = coupleLettre % 45;
                    

                    lettre1 = (coupleLettre - lettre2) / 45;
                    
                    res += (char)((int)65 + lettre1 - 10);
                    //Console.WriteLine(res);
                    
                    res += (char)((int)65 + lettre2 - 10);
                    //Console.WriteLine(res);
                    //Console.WriteLine((char)((int)65 + lettre1 - 10));
                    //Console.WriteLine((char)((int)65 + lettre2 - 10));
                    nom = new List<byte>();
                }


            }

            else
            {
                int coupleLettre, lettre1, lettre2;
                for (int i = 0; i < ((taille - 1) / 2); i++)
                {
                    for (int j = 0; j < 11; j++)
                    {
                        nom.Add(tab[j + 9 + cpt]);
                    }
                    cpt += 11;
                    //Console.WriteLine();
                    //AfficherList(nom);
                    coupleLettre = FromBintoInt(FromListToTab(nom), 0, 11);
                    //Console.WriteLine("Total = " + coupleLettre);
                    lettre2 = coupleLettre % 45;
                    //Console.WriteLine("Lettre 2 " + lettre2);

                    lettre1 = (coupleLettre - lettre2) / 45;
                    //Console.WriteLine("Lettre 1 " + lettre1);
                    
                    res += (char)((int)65 + lettre1 - 10);
                    //Console.WriteLine(res);
                    res += (char)((int)65 + lettre2 - 10);
                    //Console.WriteLine(res);
                    nom = new List<byte>();

                }
                for (int j = 0; j < 6; j++)
                {
                    nom.Add(tab[j + 9 + cpt]);
                }

                //Console.WriteLine();
                //AfficherList(nom);
                coupleLettre = FromBintoInt(FromListToTab(nom), 0,6)+1;
                //Console.WriteLine("Total = " + coupleLettre);

                //Console.WriteLine((char)((int)65 + coupleLettre - 10));
                res += (char)((int)65 + coupleLettre - 10);

            }
            return res;
        }
        public char[] BintoChar(byte[] tab,int cpt)
        {
            char[] res = new char[2];
            int coupleLettre, lettre1, lettre2;
            List<byte> nom = new List<byte>();
            for (int j = 0; j < 11; j++)
            {
                nom.Add(tab[j + 9 + cpt]);
            }
            
            //Console.WriteLine();
            //AfficherList(nom);
            coupleLettre = FromBintoInt(FromListToTab(nom), 0, 11);
            //Console.WriteLine("Total = " + coupleLettre);
            lettre2 = coupleLettre % 45;
            //Console.WriteLine("Lettre 2 " + lettre2);

            lettre1 = (coupleLettre - lettre2) / 45;
            //Console.WriteLine("Lettre 1 " + lettre1);
            //Console.WriteLine((char)((int)65 + lettre1 - 10));
            //Console.WriteLine((char)((int)65 + lettre2 - 10));
            res[0] = (char)((int)65 + lettre1 - 10);
            res[1] = (char)((int)65 + lettre2 - 10);
            return res;
        }
        public byte[] FromBintoByte(List<byte> lis)
        {
            List<byte> res = new List<byte>();
            int cpt = 0;
            byte re = 0;
            for (int j = 0; j < lis.Count() / 8; j++)
            {
                for (int i = 0; i < 8; i++)
                {
                    re += (byte)Math.Pow(Convert.ToInt32(lis.ElementAt(cpt)), 7 - i);
                    cpt++;
                }
                res.Add(re);

            }
            return FromListToTab(res);
        }
        public int FromBintoInt(byte[]tab,int indexdépart,int nbbyte)
        {
            int res = 0;
            for(int i = 0;i<nbbyte;i++)
            {
                res += (int)(tab[nbbyte-1 - i] * Math.Pow(2, i));
            }
            return res;
        }
        public static byte[] InttoByte(int nb, int nbbite)
        {
            List<byte> res = new List<byte>();
            while (nb != 1)
            {
                if (nb == 0)
                {
                    res.Add(0);
                    break;
                }
                else
                {
                    res.Add(Convert.ToByte(nb % 2));
                    nb = nb / 2;
                }
            }
            if (nb == 1)
            {
                res.Add(1);
            }
            if (res.Count < nbbite)
            {
                while (res.Count < nbbite)
                {
                    res.Add(0);
                }
            }
            return ListToTab(res);
        }
        public static string FromTabtoString(byte[] tab)
        {
            string res = null;
            for (int i = 0; i < tab.Length; i++)
            {
                res += tab[i];
            }
            return res;
        }
        public static string FromListtoString(List<byte> Liste)
        {
            string res = "";
            for (int i = 0; i < Liste.Count(); i++)
            {
                res += Convert.ToString(Liste.ElementAt(i));
            }
            return res;
        }
        public byte[] ChartoBin(string mot)
        {
            List<byte> res1 = new List<byte>();
            mot = mot.ToUpper();
            byte[] b = null;
            if (mot.Length % 2 == 0)
            {
                for (int h = 0; h < mot.Length; h += 2)
                {
                    int a = (int)45 * ChartoByte(mot[h]);
                    a += (int)ChartoByte(mot[h + 1]);
                    b = InttoByte(a, 11);
                    for (int i = 0; i < b.Length; i++)
                    {
                        res1.Add(b[i]);
                    }
                }
            }
            else
            {
                for (int h = 0; h < mot.Length - 1; h += 2)
                {
                    int a = (int)45 * ChartoByte(mot[h]);
                    a = a + ChartoByte(mot[h + 1]);
                    byte[] c = InttoByte(a, 11);
                    for (int i = 0; i < c.Length; i++)
                    {
                        res1.Add(c[i]);
                    }
                }
                b = InttoByte(ChartoByte(mot[mot.Length - 1]), 6);

                for (int i = 0; i < b.Length; i++)
                {
                    res1.Add(b[i]);
                }

            }
            res1 = InverserList(res1);
            return ListToTab(res1);




            /* AUTRE LANGAGE
                string res = "";
                for(int i = 0;i<8;i++)
                {
                    if ((lettre & 1) == 1) res += "1";
                    else res += "0";
                    lettre >>= 1;

                }
                string res2 = null;
                for(int j = 0;j<res.Length;j++)
                {
                    res2 += res[res.Length - 1 - j];
                }*/
        }
        public int ChartoByte(char lettre)
        {
            int res = 0;

            switch (lettre)
            {
                case 'A':
                    res = 10;
                    break;
                case 'B':
                    res = 11;
                    break;
                case 'C':
                    res = 12;
                    break;
                case 'D':
                    res = 13;
                    break;
                case 'E':
                    res = 14;
                    break;
                case 'F':
                    res = 15;
                    break;
                case 'G':
                    res = 16;
                    break;
                case 'H':
                    res = 17;
                    break;
                case 'I':
                    res = 18;
                    break;
                case 'J':
                    res = 19;
                    break;
                case 'K':
                    res = 20;
                    break;
                case 'L':
                    res = 21;
                    break;
                case 'M':
                    res = 22;
                    break;
                case 'N':
                    res = 23;
                    break;
                case 'O':
                    res = 24;
                    break;
                case 'P':
                    res = 25;
                    break;
                case 'Q':
                    res = 26;
                    break;
                case 'R':
                    res = 27;
                    break;
                case 'S':
                    res = 28;
                    break;
                case 'T':
                    res = 29;
                    break;
                case 'U':
                    res = 30;
                    break;
                case 'V':
                    res = 31;
                    break;
                case 'W':
                    res = 32;
                    break;
                case 'X':
                    res = 33;
                    break;
                case 'Y':
                    res = 34;
                    break;
                case 'Z':
                    res = 35;
                    break;
                case '$':
                    res = 37;
                    break;
                case '%':
                    res = 38;
                    break;
                case '*':
                    res = 39;
                    break;
                case '+':
                    res = 40;
                    break;
                case '-':
                    res = 41;
                    break;
                case '.':
                    res = 42;
                    break;
                case '/':
                    res = 43;
                    break;
                case ':':
                    res = 44;
                    break;
                case ' ':
                    res = 36;
                    break;




            }
            return res;
        }


        //Permet de faire de la traduction en tableau de Pixel et de l'exportation
        public List<byte> FromPixtoByte(List<Pixel> lis)
        {
            List<byte> res = new List<byte>();
            for(int i =0;i<lis.Count();i++)
            {
                if(lis.ElementAt(i).R == 0)
                {
                    res.Add(1);
                }
                else
                {
                    res.Add(0);
                }
            }
            return res;
        }
        public void Export(Pixel[,]mat, string filee)
        {
            RemplirNull(mat);
            Myimage res = new Myimage(mat, "coco.bmp");
            res.Rotation(180);
            res.Miroir();
            res.AgranRetre(800);
            res.From_Image_To_File(filee);
        }
        public int[] DebutImage(Pixel[,]mat)
        {
            int i = 0;
            int j = 0;
            int xdebut = -1;
            int ydebut = -1;
            while (i < mat.GetLength(0) && xdebut == -1)
            {
                while (j < mat.GetLength(1) && xdebut == -1)
                {
                    if (mat[i, j].R == 0)
                    {
                        xdebut = i;
                        ydebut = j;
                    }
                    j++;
                }
                i++;
                j = 0;
            }
            i = mat.GetLength(0)-1;
            j = mat.GetLength(1)-1;
            int xdebut2 = -1;
            int ydebut2 = 0;
            while (i > 0 && xdebut2 == -1)
            {
                while (j > 0 && xdebut2 == -1)
                {
                    if (mat[i, j].R == 0)
                    {
                        xdebut2 = i;
                        ydebut2 = j;
                    }
                    j--;
                }
                i--;
                j = mat.GetLength(1)-1;
            }
            return new int[] { xdebut, ydebut,xdebut2,ydebut2 };
        }
        public Pixel[] FromBytetoPixel(List<byte> lis)
        {
            Pixel[] res = new Pixel[lis.Count()];
            for(int i = 0;i<lis.Count;i++)
            {
                if(lis.ElementAt(i) == 0)
                {
                    res[i] = new Pixel(255, 255, 255);
                }
                else
                {
                    res[i] = new Pixel(0, 0, 0);
                }
            }
            return res;
        }
        public static void RemplirNull(Pixel[,] mat)
        {
            for (int i = 0; i < mat.GetLength(0); i++)
            {
                for (int j = 0; j < mat.GetLength(1); j++)
                {
                    if (mat[i, j] == null)
                    {
                        mat[i, j] = new Pixel(0, 0, 0);
                    }
                }
            }
        }
        //CREATION DU MOTIF DU QR CODE
        public Pixel[,] MotifCoin(int hauteur, int largeur)
        {
            Pixel[,] res = new Pixel[hauteur, largeur];
            for (int i = 0; i < largeur; i++)
            {
                res[i, 0] = new Pixel(0, 0, 0);
                res[0, i] = res[i, 0];
                res[res.GetLength(0) - 1, i] = res[0, 1];
                res[i, res.GetLength(1) - 1] = res[0, 1];
            }
            for (int j = 0; j < largeur - 2; j++)
            {
                res[j + 1, 1] = new Pixel(255, 255, 255);
                res[1, j + 1] = res[j + 1, 1];
                res[res.GetLength(0) - 2, j + 1] = new Pixel(255, 255, 255);
                res[j + 1, res.GetLength(1) - 2] = new Pixel(255, 255, 255);
            }
            for (int z = 0; z < largeur - 4; z++)
            {
                res[z + 2, 2] = new Pixel(0, 0, 0);
                res[2, z + 2] = res[z + 2, 2];
                res[res.GetLength(0) - 3, z + 2] = new Pixel(0, 0, 0);
                res[z + 2, res.GetLength(1) - 3] = new Pixel(0, 0, 0);
            }

            res[(int)Math.Truncate(Convert.ToDecimal(largeur / 2)), (int)Math.Truncate(Convert.ToDecimal(hauteur / 2))] = new Pixel(0, 0, 0);
            return res;
        }


        public bool Validateur(List<byte>tab)
        {
            bool res = true;
            byte[] valid = { 0, 0, 1, 0, 0, 0, 0, 0,  0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1,  0, 1, 1, 1, 1, 0, 0, 0,  1, 1, 0, 1, 0, 0, 0, 1,0, 1, 1, 1, 0, 0, 1, 0 , 1, 1, 0, 1, 1, 1, 0, 0,  0, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0,  1, 1, 1, 0, 1, 1, 0, 0,  0, 0, 0, 1, 0, 0, 0, 1,  1, 1, 1, 0, 1, 1, 0, 0,  0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 0, 0,  0, 0, 0, 1, 0, 0, 0, 1,1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 0, 0 };
         for (int i = 0; i < tab.Count; i++)
            {
                if(tab.ElementAt(i) != valid[i])
                {
                    res = false;
                    Console.WriteLine("Sortie : " + tab.ElementAt(i));
                    Console.WriteLine("Attendu : " + valid[i]);
                    Console.WriteLine("Erreur au numéro " + i );
                }
            }
            return res;
        }
        
        //Permet de faire différentes manipulation sur les List et les tableau
        public static byte[] ListToTab(List<byte> lis)
        {
            byte[] res = new byte[lis.Count()];
            for (int t = 0; t < lis.Count; t++)
            {
                res[t] = lis.ElementAt(lis.Count - 1 - t);
            }
            return res;
        }
        public List<byte> InverserList(List<byte> lis)
        {
            List<byte> res = new List<byte>();
            for (int i = 0; i < lis.Count(); i++)
            {
                res.Add(lis.ElementAt(lis.Count-1-i));
            }
            return res;

        }
        public static void AjouterListTab(List<byte> lis, byte[] tab)
        {
            for (int i = 0; i < tab.Length; i++)
            {
                lis.Add(tab[i]);
            }
        }
        public static string AfficherTab(byte[] tab)
        {
            string res = null;
            for (int i = 0; i < tab.Length; i++)
            {
                res += tab[i] + " , ";
            }
            return res;
        }
        public static byte[] FromListToTab(List<byte> lis)
        {
            byte[] res = new byte[lis.Count()];
            for (int i = 0; i < res.Length; i++)
            {
                res[i] = lis.ElementAt(i);
            }
            return res;
        }
        public List<byte> FromTabToList(byte[] tab)
        {
            List<byte> rese = new List<byte>();
            for (int i = 0; i < tab.Length; i++)
            {
                rese.Add(tab[i]);
            }
            return rese;
        }
        public static void AfficherList(List<byte> tab)
        {
            for (int i = 0; i < tab.Count; i++)
            {
                Console.Write(tab.ElementAt(i) + " , ");
            }
        }
        public void EnleverBitList(List<byte> lis, int indexdebut, int nbbyte)
        {
            for (int i = indexdebut; i < nbbyte; i++)
            {
                lis.RemoveAt(i);
            }
        }
            //ATTENTION C'EST UN AUTRE LANGAGE
        //BIEN PRENDRE LA METHODE DANS LE DOC (EN SOIT ON AVAIT BIEN COMMENCER)
        //MODIFIER AVEC LES LIGNES DANS LE DEBUT DU PROGRAM
    }
}
/*
           this.nom = nom.ToUpper();
           //Console.WriteLine(InttoByte(59));
           Console.WriteLine(ChartoByte('T'));

           //Console.WriteLine(InttoByte(5));
          // Console.WriteLine("Conversion binaire du nombre : 5 donne :  " + InttoByte(5));
           this.longmot = nom.Length;
           string spli = null;
           List<byte> bin = new List<byte>();
           for (int i = 0; i < longmot-2; i+=2)
           {
               spli = Convert.ToString(nom[i]);
               spli += nom[i + 1];
               bin = ChartoBin(spli);

           }
           //Console.WriteLine("Conversion binaire du nombre : 5 donne :  " + InttoByte(5));
           string motbin = "";
           for (int i = 0; i < motbin.Count(); i++)
           {
               motbin += Convert.ToString(bin.ElementAt(i));
           }
           Console.WriteLine("Conversion binaire du mot : "+nom+" donne :  "+motbin);
           Console.WriteLine((int)'A');
           Console.WriteLine((int)'A'+2);
           Console.WriteLine((char)((int)'A'+2));
           Console.WriteLine("L'indicateur vaut : " + indicateur);

           string longmotbinstring = "";
           List<byte> longmotbin = InttoByte(nom.Length);

           for(int i = 0;i<longmotbin.Count();i++)
           {
               longmotbinstring += Convert.ToString(longmotbin.ElementAt(i));
           }
           Console.WriteLine("Longeur du mot en binaire :  " +longmotbinstring);
           Console.WriteLine("Le mot en binaire vaut : " + bin);*/
