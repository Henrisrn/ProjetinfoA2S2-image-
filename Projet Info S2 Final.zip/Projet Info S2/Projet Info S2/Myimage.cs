﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Projet_Info_S2
{
    public class Myimage
    {
        byte[] offset, fichier;
        Pixel[,] matrice;
        int hauteur, largeur, tailleOff, taillefich;
        string file4;
        ///CONSTRUCTEUR
        ///Construire une image à partir de uniquement la largeur et la longueur
        public Myimage(int largeur, int longeur)
        {
            Pixel[,] image = new Pixel[largeur,longeur];
            matrice = image;
        }
        ///Construire une image à partir d'un tableau de Pixel
        public Myimage(Pixel[,]mat,string fileee)
        {
            Myimage donnee = new Myimage(fileee);
            this.offset = donnee.Offset;
            this.tailleOff = donnee.TailleOff;
            matrice = mat;

            largeur = mat.GetLength(0);
            hauteur = mat.GetLength(1);
            EcrireOffset(18, largeur);
            EcrireOffset(22, hauteur);
            Pixel[,] res = new Pixel[largeur+12-largeur%4, largeur + 12 - largeur % 4];
            for (int i = 0; i < res.GetLength(0); i++)
            {
                for (int j = 0; j < res.GetLength(1); j++)
                {
                    if (i > 3 && j > 3 && i < matrice.GetLength(0) + 4 && j < matrice.GetLength(1)+4)
                    {
                        res[i, j] = matrice[i - 4,j-4];
                    }
                    else
                    {
                        res[i, j] = new Pixel(255, 255, 255);
                    }
                }
            }
                       
            matrice = res;
            
            taillefich = hauteur * largeur * 3 + 54; 
        }
        ///Constuire une image à partir d'un nom de dossier (récupération des données de l'image afin de pouvoir exploité ces données
        public Myimage(string file)
        {
            ///Lecture dossier
            fichier = File.ReadAllBytes(file);
            this.file4 = file;
            ///pas utilisé
            taillefich = Lire(fichier, 2);
            tailleOff = Lire(fichier, 14) + 14;
            largeur = Lire(fichier, 18);
            hauteur = Lire(fichier, 22);
           
            offset = new byte[tailleOff];
            for (int i = 0; i < tailleOff; i++)
            {
                offset[i] = fichier[i];
            }

            int cpt = tailleOff;        ///cpt = compteur
            matrice = new Pixel[largeur, hauteur];
            
                for (int i = 0; i < hauteur; i++)
                {
                    for (int j = 0; j < largeur; j++)
                    {
                        matrice[j, i] = new Pixel(fichier[cpt], fichier[cpt+1], fichier[cpt+2]);
                        cpt += 3;
                    }
                }

            ///AfficherImage(matrice);
            ///AfficherFichier();
        }

        ///GET SET (utilse si jamais on veut faire une application API
        public byte[] Offset
        {
            get { return offset; }
        }
        public int TailleOff
        {
            get { return tailleOff; }
        }
        public Pixel[,]Matrice
        {
            get { return matrice; }
        }

        ///Permet de mettre à jour l'image avec les différentes modifications qui ont été apporté
        void MaJ(Pixel[,] matrice)
        {
            this.matrice = matrice;
            largeur = matrice.GetLength(0);
            hauteur = matrice.GetLength(1);
            ///Mise a jour de l'offset lors de la sauvgarde
        }

        ///Méthode sur les différents affichage d'Image, export, import
        public void AfficherFichier()
        {
            
            Console.WriteLine('\n'+" HEADER "+'\n' );
            for (int i = 0;i<14;i++)
            {

                Console.Write(offset[i]+" ");
            }
            Console.Write('\n' + " HEADER INFO "+ '\n' );
            for(int i = 14;i<54;i++)
            {
                Console.Write(offset[i] + " ");
            }
            /*
            Console.WriteLine('\n' + " IMAGE "+ '\n' );
            for(int i = 0;i<matrice.GetLength(0);i++)
            {
                for(int j = 0;j<matrice.GetLength(1);j++)
                {
                    Console.Write(matrice[i,j].R + " " +matrice[i, j].G + " " + matrice[i, j].B + " ");
                }
            }*/
        }
        public void From_Image_To_File(string nom)
        {
            ///mise à jour info
            int padding = 0;
            while ((largeur + padding) % 4 != 0) padding++;
            taillefich = hauteur * (largeur + padding) * 3 + tailleOff;
            
            EcrireOffset(2, taillefich);
            EcrireOffset(18, largeur);
            EcrireOffset(22, hauteur);

            ///ecrire fichier
            byte[] fichier = new byte[tailleOff + hauteur * (largeur + padding) * 3];
            int cpt = tailleOff;
            for (int i = 0; i < tailleOff; i++) fichier[i] = offset[i];
            for (int i = 0; i < hauteur; i++)
            {
                for (int j = 0; j < largeur; j++)
                {
                    
                    fichier[cpt + 0] = Convert.ToByte(matrice[j, i].R);
                    fichier[cpt + 1] = Convert.ToByte(matrice[j, i].G);
                    fichier[cpt + 2] = Convert.ToByte(matrice[j, i].B);
                    cpt += 3;
                }
                for (int j = 0; j < padding; j++)
                {
                    fichier[cpt + 0] = 0;
                    fichier[cpt + 1] = 0;
                    fichier[cpt + 2] = 0;
                    cpt += 3;
                }
            }
            
            File.WriteAllBytes(nom, fichier);
        }
        static void AfficherImage(Pixel[,] mat)
        {
            Console.WriteLine("L'image fait " + mat.GetLength(0) + " byte en largeur et " + mat.GetLength(1) + " byte en longueur");
            for (int i = 0; i < mat.GetLength(0); i++)
            {
                for (int j = 0; j < mat.GetLength(1); j++)
                {
                    if (mat[i, j] != null)
                    {
                        Console.Write(mat[i, j].R + " | ");
                        ///+ "|" + mat[i, j].G + "|" + mat[i, j].B + "|");
                    }
                    else
                    {
                        Console.Write("NULL  | ");
                    }
                }
                Console.WriteLine();
            }
        }
        ///Outils de Conversion pour traité la données issus des Offset
        static int Convert_Endian_To_Int(byte[]tab)
        {
            int s = 0;
            for(int i = 0;i<tab.Length;i++)
            {
                int t = Convert.ToInt32(Math.Pow(256, i));
                s += tab[i] *t;
               
             }
            return s;
        }
        static byte[] Convertir_Int_To_Endian(int n)
        {
            byte[] tab = new byte[4];
            for(int i = 3;i> -1; i--)
            {
                tab[i] = Convert.ToByte(n / Convert.ToInt32(Math.Pow(256, i)));
                n = n % Convert.ToInt32(Math.Pow(256, i));
            }
            return tab;
        }

        ///Permet de Lire et d'écrire dans l'Offset
        int Lire(byte[] fichier, int premierIndice)
        {
            byte[] tabByte = new byte[] { fichier[premierIndice], fichier[premierIndice + 1], fichier[premierIndice + 2], fichier[premierIndice + 3] };
            return Convert_Endian_To_Int(tabByte);
        }
        void EcrireOffset(int premierIndice, int valeur)
        {
            byte[] tabByte = Convertir_Int_To_Endian(valeur);
            for (int i = 0; i < 3; i++)
            {
                offset[premierIndice + i] = tabByte[i];
            }
        }        

       
        ///METHODE DE MANIPULATION D'IMAGE (SUJET)
        ///Noir et Blanc
        public void NB()
        {
            int somme;      ///eviter depasser 255 lorsque l'on somme les 3 couleurs
            for (int i = 0; i < largeur; i++)
            {
                for (int j = 0; j < hauteur; j++)
                {
                    somme = matrice[i, j].R + matrice[i, j].G + matrice[i, j].B;
                    somme /= 3;
                    if (somme > 255 / 2)
                    {
                        matrice[i, j] = new Pixel(255, 255, 255);
                    }
                    else
                    {
                        matrice[i, j] = new Pixel(0, 0, 0);
                    }
                }
            }
        }
        ///Nuance de Gris
        public void Gris()
        {
            int somme;      ///eviter depasser 255 lorsque l'on somme les 3 couleurs
            byte moyenne;

            for (int i = 0; i < largeur; i++)
            {
                for (int j = 0; j < hauteur; j++)
                {
                    somme = matrice[i, j].R + matrice[i, j].G + matrice[i, j].B;
                    moyenne = Convert.ToByte(somme / 3);
                    matrice[i, j].R = moyenne;
                    matrice[i, j].G = moyenne;
                    matrice[i, j].B = moyenne;
                }
            }
        }
        ///Miroir de l'image
        public void Miroir()
        {
            Pixel[,] MatFinal = new Pixel[largeur, hauteur];
            for (int i = 0; i < MatFinal.GetLength(0); i++)
            {
                for (int j = 0; j < MatFinal.GetLength(1); j++)
                {
                    MatFinal[i, j] = matrice[largeur - 1 - i, j];
                }
            }
            MaJ(MatFinal);
        }
        ///Agrandir ou Rétrécir une image
        public void AgranRetre(double coeff)
        {
            

            coeff = Convert.ToDouble(coeff)/100;
            int hauteur0 = Convert.ToInt32(hauteur * coeff);
            int largeur0 = Convert.ToInt32(largeur * coeff);

            Pixel[,] res = new Pixel [largeur0, hauteur0];
            
            for(int i = 0; i< largeur0; i++)
            {
                for(int j = 0; j< hauteur0; j++)
                {
                    int i0 = Convert.ToInt32(i / coeff);
                    int j0 = Convert.ToInt32(j / coeff);
                    
                    if (i0 < largeur && j0 < hauteur)
                    {
                        res[i, j] = matrice[i0, j0];
                    }
                    else
                    {
                        if(i0 == largeur)
                        {
                            i0--;
                        }
                        if(j0 == hauteur)
                        {
                            j0--;
                        }
                        res[i, j] = matrice[i0,j0];
                        /*
                        if (i0 == 0)
                        {
                            res[i, j] = matrice[i0+1, j0];
                        }
                        if(j0 == hauteur)
                        {
                            res[i, j] = matrice[i0, j0-1 ];
                        }*/
                        
                    }
                         
                    ///res[i, j] = matrice[Convert.ToInt32(i / coeff) , Convert.ToInt32(j / coeff)];
                }
            }
            MaJ(res);
        }
        ///Tourner une image de 90 degrée (utile lors de la roation)
        public void Tour90()
        {
            Pixel[,] res = new Pixel[matrice.GetLength(1), matrice.GetLength(0)];
            for (int i = 0; i < matrice.GetLength(0); i++)
            {
                for (int j = 0; j < matrice.GetLength(1); j++)
                {
                    res[j, i] = matrice[i, j];
                    
                }
            }
            matrice = res;
            MaJ(matrice);
        }
        ///Tourner de 180 degrée
        public void Tour180()
        {
            Pixel[,] res = new Pixel[matrice.GetLength(0), matrice.GetLength(1)];
            for (int i = 0; i < matrice.GetLength(0); i++)
            {
                for (int j = 0; j < matrice.GetLength(1); j++)
                {
                    res[i, j] = matrice[matrice.GetLength(0)-1-i, matrice.GetLength(1)-1-j];

                }
            }
            matrice = res;
            MaJ(matrice);
        }
        ///Permet de faire la rotation d'une image pour n'importe quelle angle
        public void Rotation(double angle)
        {
            
            angle %= 360;
            
            if (angle == 180)
            {
                Tour180();
            }
            else
            {
                if (angle % 90 == 0)
                {
                    int nbtour = Convert.ToInt32(angle / 90);

                    for (int t = 0; t < nbtour; t++)
                    {
                        Tour90();
                    }
                    MaJ(matrice);
                }
                else
                {
                    /// CE QUI RESTE A FAIRE : FAIRE LE MODULO DE L'ANGLE AVANT ET PUIS ENSUITE ATTAQUER SINON POUR LE RESTE CA A L'AIR DE MARCHE
                    
                    int x = (int)Math.Truncate(angle / 90);
                    if (x != 0)
                    {
                        for (int t = 0; t < x; t++)
                        {
                            Tour90();
                        }
                    }
                    angle %= 90;
                    angle = (Math.PI / 180) * angle;
                    int hauteur2 = (int)Math.Round(Math.Cos(angle)*matrice.GetLength(0)+Math.Sin(angle)*matrice.GetLength(1));
                    int largeur2 = Convert.ToInt32(Math.Round(Math.Cos(angle) * matrice.GetLength(1) + Math.Sin(angle) * matrice.GetLength(0)));
                    if(hauteur2 < 0)
                    {
                        hauteur2 = hauteur2 * (-1); 

                    }
                    if (largeur2 < 0)
                    {
                        largeur2 = largeur2 * (-1);
                    }
                    Pixel[,] res = new Pixel[hauteur2, largeur2];
                   
                    for (double i = 0; i < matrice.GetLength(0) - 0.5; i += 0.5)
                    {
                        for (double j = 0; j < matrice.GetLength(1) - 0.5; j += 0.5)
                        {
                            res[Convert.ToInt32(Math.Floor(Math.Sin(angle)*(matrice.GetLength(1)-1)-Math.Sin(angle)* j + Math.Cos(angle) * i)) , Convert.ToInt32(Math.Floor(Math.Cos(angle) * j + Math.Sin((angle)) * i))] = matrice[(int)Math.Floor(i), (int)Math.Floor(j)];
                        }
                    }
                    for(int i = 0;i<res.GetLength(0);i++)
                    {
                        for(int j = 0;j<res.GetLength(1);j++)
                        {
                            if(res[i,j] == null)
                            {
                                res[i, j] = new Pixel(255, 255, 255);
                            }
                        }
                    }
                    
                    MaJ(res);

                }
               
            }
             /*
                default:
                    for (int i = 0; i < matrice.GetLength(0); i++)
                    {
                        for (int j = 0; j < matrice.GetLength(1); j++)
                        {

                            int xNoyau = Convert.ToInt32(matrice.GetLength(1) / 2);
                            int yNoyau = Convert.ToInt32(matrice.GetLength(0) / 2);
                            double rad = angle * (Math.PI / 180);

                            int c = Convert.ToInt32(Math.Cos(rad) * (j - xNoyau) - Math.Sin(rad) * (i - yNoyau)) + xNoyau;
                            int d = Convert.ToInt32(Math.Sin(rad) * (j - xNoyau) - Math.Cos(rad) * (i - yNoyau)) + yNoyau;
                            if ((c >= 0) && (c < matrice.GetLength(1)) && (d >= 0) && (d < matrice.GetLength(0)))
                            {
                                byte R = matrice[d, c].R;
                                byte G = matrice[d, c].G;
                                byte B = matrice[d, c].B;

                                matrice[i, j] = new Pixel(R, G, B);
                            }
                        }
                    }
                    break;
            }*/
        }

        ///MATRICE DE CONVOLUTION
        ///Outils de manipulation de la matrice de Convolution
        Pixel[,] MatConv(double[,] kernel)
        {
            Pixel[,] res = new Pixel[largeur, hauteur];
            double[,] MatR = new double[largeur, hauteur];
            double[,] MatG = new double[largeur, hauteur];
            double[,] MatB = new double[largeur, hauteur];
            for(int i = 0; i<largeur;i++)
            {
                for(int j = 0;j<hauteur;j++)
                {
                    MatR[i, j] = Convert.ToDouble(matrice[i, j].R);
                    MatG[i, j] = Convert.ToDouble(matrice[i, j].G);
                    MatB[i, j] = Convert.ToDouble(matrice[i, j].B);
                }
            }
            int[,] ConvoR = ApplicationNoyau(MatR, kernel);
            int[,] ConvoG = ApplicationNoyau(MatG,kernel);
            int[,] ConvoB = ApplicationNoyau(MatB,kernel);
            
            for(int i = 0;i<largeur;i++)
            {
                for(int j = 0;j<hauteur;j++)
                {
                    Pixel a = new Pixel(Convert.ToByte(ConvoR[i, j]), Convert.ToByte(ConvoG[i, j]),Convert.ToByte(ConvoB[i, j]));
                    res[i, j] = a;
                }
            }
            return res;
        }
        public int[,] ApplicationNoyau(double[,] Mat, double[,]CoeffCentre)
        {
            int a;
            int b;
            double somme;
            double[,] MatCentre = new double[3, 3];
            int[,] res = new int[Mat.GetLength(0), Mat.GetLength(1)];
           
            for(int i = 0;i<largeur;i++) ///On pose nos variables pour balayé notre matrice principal
            {
                for(int j = 0;j<hauteur;j++)
                {
                    
                    for(int x = -1;x<2;x++) ///On pose nos variables pour étudier notre kernel
                    {
                        for(int y = -1;y<2;y ++)
                        {
                            a = i + x;
                            b = j + y;
                            
                            ///On pose les différents cas pour les coordonnées des côtés de notre matrice
                            if (a == -1) a = Mat.GetLength(0);
                            if (a == Mat.GetLength(0)) a = 0;
                            if(j+y == -1) b = Mat.GetLength(1) - 1;
                            if(j+y == Mat.GetLength(1)) b = 0;
                           
                            MatCentre[x + 1,y + 1] = CoeffCentre[x + 1, y + 1] * Mat[a, b];
                        }
                    }

                    somme = 0;
                    for(int x = 0;x<3;x++)
                    {
                        for(int y = 0;y<3;y++)
                        {
                            somme += MatCentre[x, y];
                        }
                    }
                    if(somme<0) somme = 0;
                    if(somme > 255) somme = 255;
                    res[i, j] = Convert.ToInt32(somme);
                }
            }
            return res;
        }

        ///Matrice de Convolution Type pour Manipuler notre image
        public void Flou()
        {
            double[,]Centre = new double[,] { { 1 / 9.0, 1 / 9.0, 1 / 9.0 }, { 1 / 9.0, 1 / 9.0, 1 / 9.0 }, { 1 / 9.0, 1 / 9.0, 1 / 9.0 } };
            MaJ( MatConv(Centre) );
        }
        public void Detect(int niveau)
        {
            double[,] Centre;
            switch(niveau)
            {
                case 1:
                    Centre = new double[,] { { 1, 0, -1 }, { 0, 0, 0 }, { -1, 0, 1 } };
                    break;
                case 2:
                    Centre = new double[,] { { -1, -1, -1 }, { -1, 8, -1 }, { -1, -1, -1 } };
                    break;
                case 3:
                    Centre = new double[,] { { 0, 0, 0 }, { 0, 1, 0 }, { 0, 0, 0 } };
                    break;
                default:
                    Centre = new double[,] { { 0, 0, 0 }, { 0, 8, 0 }, { 0, 0, 0 } };
                    break;

            }
            MaJ(MatConv(Centre));
        }
        public void Repoussage()
        {
            double[,] Centre = new double[,] { { -2, -1, 0 }, { -1, 1, 1 }, { 0, 1, 2 } }; ;
            MaJ(MatConv(Centre));
        }
        public void Renfor()
        {
            double[,] Centre = new double[,] { { 0, 0, 0 }, { -1, 1, 0 }, { 0, 0, 0 } };
            MaJ(MatConv(Centre));
        }
        public void Contrast()
        {
            double[,] Centre = new double[,] { { 0, -1, 0 }, { -1, 5, -1 }, { 0, -1, 0 } };
            MaJ(MatConv(Centre));
        }
        public void FiltreSobel()
        {
            double[,] Centre = new double[,] { { -1, 0, 1 }, { -2, 0, 2 }, { -1, 0, 0 } };
            MaJ(MatConv(Centre));
        }
        ///HISTOGRAMME
        ///Création d'un Histogramme à partir d'une Image
        public void Histo()
        {
            ///frequence des couleur
            byte[,] rouge = new byte[matrice.GetLength(0), matrice.GetLength(1)];
            byte[,] vert = new byte[matrice.GetLength(0), matrice.GetLength(1)];
            byte[,] bleu = new byte[matrice.GetLength(0), matrice.GetLength(1)];

            for (int i = 0; i < matrice.GetLength(0); i++)
            {
                for (int j = 0; j < matrice.GetLength(1); j++)
                {
                    rouge[i, j] = matrice[i, j].R;
                    vert[i, j] = matrice[i, j].G;
                    bleu[i, j] = matrice[i, j].B;
                }
            }
            
            int[] freqR = FrequenceCouleur(rouge);
            int[] freqG = FrequenceCouleur(vert);
            int[] freqB = FrequenceCouleur(bleu);

            ////calcul le max possible
            int max = 0;
            for (int i = 0; i < 256; i++)
            {
                if (max < freqR[i]) max = freqR[i];
                if (max < freqG[i]) max = freqG[i];
                if (max < freqB[i]) max = freqB[i];
            }
            hauteur = max;      ///temporaire


            Pixel[,] TabR = HistoCouleur(hauteur, freqR, new Pixel(255, 0, 0));
            Pixel[,] TabG = HistoCouleur(hauteur, freqG, new Pixel(0, 255, 0));
            Pixel[,] TabB = HistoCouleur(hauteur, freqB, new Pixel(0, 0, 255));

            Pixel[,] mat = new Pixel[256, hauteur * 3];
            for (int i = 0; i < 256; i++)
            {
                for (int j = 0; j < hauteur; j++)
                {
                    mat[i, j] = TabB[i, j];
                    mat[i, j + hauteur] = TabG[i, j];
                    mat[i, j + 2*hauteur] = TabR[i, j];
                }

            }
            MaJ(mat);
        }
        static int[] FrequenceCouleur(byte[,] TabCouleur)
        {
            int[] frequence = new int[256];
            ///set toutes les valeurs d'une couleur à zéro
            for (int i = 0; i < 256; i++) frequence[i] = 0;
            ///incremente une valeur de la frequence de couleur dès qu'elle apparait dans le tableau
            for (int i = 0; i < TabCouleur.GetLength(0); i++)
            {
                for (int j = 0; j < TabCouleur.GetLength(1); j++)
                {
                    frequence[TabCouleur[i, j]]++;
                }
            }
            return frequence;
        }
        ///Permet de définir la fréquence d'une couleur dans une image
        static Pixel[,] HistoCouleur(int hauteur, int[] freq, Pixel couleur)
        {
            Pixel[,] Tab = new Pixel[256, hauteur];
            for (int i = 0; i < 256; i++)
            {
                for (int j = 0; j < hauteur; j++)
                {
                    if (j <= freq[i]) Tab[i, j] = couleur;
                    else Tab[i, j] = new Pixel(255, 255, 255);
                }
            }
            return Tab;
        }
        ///FRACTALE
        public void Fractale()
        {

            /*int a = -2;
            int b = 1;
            int c = -1;
            int d = 1;*/

            ///Pour Mandelbrot mais elle marche pas donc nique

            
            int nbIntération = 50;
            hauteur = 3000;
            largeur = 3000;
            double c_r = 0;
            double c_i = 0;
            double z_r = 0;
            double z_i = 0;
            
            int k = 0;
            double tmp = 0;
            Pixel[,] res = new Pixel[hauteur, largeur];
            for (int i = 0; i < hauteur; i++)
            {
                for (int j = 0; j < largeur; j++)
                {
                    c_r = Convert.ToDouble(i - (hauteur) / 2) / (Convert.ToDouble(hauteur / 3));
                    c_i = Convert.ToDouble(j - (largeur) / 2) / (Convert.ToDouble(largeur / 3));
                    z_r = 0;
                    z_i = 0;
                    k = 0;
                    while (k < nbIntération && z_r * z_r + z_i * z_i < 4)
                    {
                        tmp = z_r;
                        z_r = z_r * z_r - z_i * z_i + c_r;
                        z_i = 2 * z_i * tmp + c_i;
                        k++;
                    }
                    if (k == nbIntération)
                    {
                        res[i, j] = new Pixel(0, 0, 0);
                    }
                    else
                    {
                        res[i, j] = new Pixel(Convert.ToByte(k * 255 / nbIntération), 0, Convert.ToByte(k * 255 / nbIntération));
                    }
                }
            }
            this.matrice = res;
            MaJ(res);
           
            /*
            
            double x1 = -2.1;
            double x2 = 0.6;
            double y1 = -1.2;
            double y2 = 1.2;
            int zoom = 100;
            int iteration_max = 100;

            double image_x = (x2 - x1) * zoom;
            double image_y = (y2 - y1) * zoom;

            /// un tableau que l'on va incrémenter à chaque fois que la suite Z_n passera par un point.
            int[,] res = new int[Convert.ToInt32(image_x), Convert.ToInt32(image_y)];

            /// en théorie, on devrait faire une seul boucle dans laquelle on devrait prendre les coordonnés (x; y) au hasard.
            for (int x = 0; x < image_x; x++)
            {
                for (int y = 0; y < image_y; y++)
                {
                    double c_r = x / zoom + x1;
                    double c_i = y / zoom + y1;
                    double z_r = 0;
                    double z_i = 0;
                    int i = 0;
                    List<int> tmp_pixels = new List<int>();
                    c_r = x / zoom + x1;
                    c_i = y / zoom + y1;
                    z_r = 0;
                    z_i = 0;
                    i = 0;
                    do
                    {
                        double tmp = z_r;
                        z_r = z_r * z_r - z_i * z_i + c_r;
                        z_i = 2 * z_i * tmp + c_i;
                        i = i + 1;

                        while ((z_r * z_r + z_i * z_i) < 4 && i < (iteration_max))
                        {
                            if (i != iteration_max)
                            {
                                foreach (int valeurs in tmp_pixels)
                                {
                                    if (res[0, i] != null)
                                    {
                                        i++;
                                    }
                                }

                            }

                        }
                    }
                }
            }
            for (int i = 0; i < image_x; i++)
            {
                for (int j = 0; j < image_y; j++)
                {
                    res[i, j] = new Pixel(Math.Min(res[x][y], 255), Math.Min(pixels[x][y], 255), Math.Min(pixels[x][y], 255));
                }
            }*/
        
    
   


        }

        ///Encodage d'une Image
        public void EncoderImage()
        {
            Pixel[,] res = new Pixel[matrice.GetLength(0), matrice.GetLength(1)];
            int largeur2 = matrice.GetLength(0);
            int hauteur2 = matrice.GetLength(1);
            string[,] tabR = new string[largeur2, hauteur2];
            string[,] tabG = new string[largeur2, hauteur2];
            string[,] tabB = new string[largeur2, hauteur2];
            ///Compléter 
            for(int i = 0;i<largeur2;i++)
            {
                for(int j = 0;j<hauteur2;j++)
                {
                    
                    tabR[i, j] = QRcode.FromTabtoString(QRcode.InttoByte(matrice[i, j].R,8));
                    tabG[i, j] = QRcode.FromTabtoString(QRcode.InttoByte(matrice[i, j].G, 8));
                    tabB[i, j] = QRcode.FromTabtoString(QRcode.InttoByte(matrice[i, j].B, 8));
                }
            }
            Supp4bit(tabR);
            Supp4bit(tabG);
            Supp4bit(tabB);

            Completer(tabR);
            Completer(tabG);
            Completer(tabB);
            

        }
        ///Cache Image
        public void CacherImage(Myimage Image2)
        {
            int largeur2 = matrice.GetLength(0);
            int hauteur2 = matrice.GetLength(1);
            string[,] tabR = new string[largeur2, hauteur2];
            string[,] tabG = new string[largeur2, hauteur2];
            string[,] tabB = new string[largeur2, hauteur2];
            string[,] tabRcacher = new string[largeur2, hauteur2];
            string[,] tabGcacher = new string[largeur2, hauteur2];
            string[,] tabBcacher = new string[largeur2, hauteur2];

            for (int i = 0; i < largeur2; i++)
            {
                for (int j = 0; j < hauteur2; j++)
                {
                    
                    tabR[i, j] = QRcode.FromTabtoString(QRcode.InttoByte(matrice[i, j].R, 8));
                    tabG[i, j] = QRcode.FromTabtoString(QRcode.InttoByte(matrice[i, j].G, 8));
                    tabB[i, j] = QRcode.FromTabtoString(QRcode.InttoByte(matrice[i, j].B, 8));

                    tabRcacher[i, j] = QRcode.FromTabtoString(QRcode.InttoByte(Image2.matrice[i, j].R, 8));
                    tabGcacher[i, j] = QRcode.FromTabtoString(QRcode.InttoByte(Image2.matrice[i, j].G, 8));
                    tabBcacher[i, j] = QRcode.FromTabtoString(QRcode.InttoByte(Image2.matrice[i, j].B, 8));
                }
            }
            SuppNull(tabRcacher);
            SuppNull(tabGcacher);
            SuppNull(tabBcacher);

            Supp4dernier(tabR);
            Supp4dernier(tabG);
            Supp4dernier(tabB);

            Supp4dernier(tabRcacher);
            Supp4dernier(tabGcacher);
            Supp4dernier(tabBcacher);

            string[,] tabRfin = Rassembler(tabR, tabRcacher);
            string[,] tabGfin = Rassembler(tabG, tabRcacher);
            string[,] tabBfin = Rassembler(tabB, tabRcacher);
            
            Completer(tabRfin);
            Completer(tabGfin);
            Completer(tabBfin);

            for (int i = 0;i<tabRfin.GetLength(0);i++)
            {
                for(int j = 0;j<tabRfin.GetLength(1);j++)
                {
                    matrice[i, j] = new Pixel((byte)Convert.ToInt32(tabRfin[i,j],2), (byte)Convert.ToInt32(tabGfin[i, j],2), (byte)Convert.ToInt32(tabBfin[i, j],2));
                }
            }
        }

        ///Outils permettant de rassemblé 2 tableaux
        public string[,] Rassembler(string[,]tab1, string[,]tab2)
        {
            string[,] res = new string[tab1.GetLength(0), tab1.GetLength(1)];
            for(int i = 0;i<res.GetLength(0);i++)
            {
                for(int j = 0;j< res.GetLength(1);j++)
                {
                    res[i, j] = tab1[i, j] + tab2[i, j];
                }
            }
            return res;
        }
        ///Outils permettant de supprimé les éléments null d'un tableaux
        public void SuppNull(string[,]tab)
        {
            
            for(int i = 0;i<tab.GetLength(0);i++)
            {
                for(int j = 0;j<tab.GetLength(1);j++)
                {
                    if(tab[i,j] == null)
                    {
                        tab[i, j] = "00000000";
                    }
                }
            }
        }
        ///Outils pour supprimer les 4 derniet Bits d'un tableaux
        public string[,]Supp4dernier(string[,]tab)
        {
            string[,] res = new string[tab.GetLength(0), tab.GetLength(1)];
            for(int i =0;i<tab.GetLength(0);i++)
            {
                for(int j = 0;j<tab.GetLength(1);j++)
                {
                    res[i, j] = tab[i, j].Substring(4, 4);
                }
            }
            return res;
        }
        ///Outils pour supprimer les 4 premier Bits d'un tableaux
        public string[,] Supp4bit(string[,]tab)
        {
            string[,] res = new string[tab.GetLength(0), tab.GetLength(1)];
            for(int i = 0;i<tab.GetLength(0);i++)
            {
                for(int j = 0;j<tab.GetLength(1);j++)
                {
                    res[i, j] = tab[i, j].Substring(0, 4);
                }
            }
            return res;
        }
        ///Outils pour Compléter un tableau
        public string[,] Completer(string[,]tab)
        {
            string[,] res = new string[tab.GetLength(0),tab.GetLength(1)];
            for(int i = 0;i<res.GetLength(0);i++)
            {
                for(int j = 0;j<res.GetLength(1);j++)
                {
                    res[i, j] = tab[i, j].PadRight(8, '0');
                }
            }
            return res;
        }
         

     }
}
