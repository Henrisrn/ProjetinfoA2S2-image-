﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using System.Diagnostics;

namespace Projet_Info_S2
{
    public class Program
    {
        public static void Affichermenu()
        {
            string fichier = File.ReadAllText("TestLectureBrut.txt");
            Console.WriteLine(fichier);
        }
        public static string ChoisirImage()
        {
            Console.WriteLine("Quel fichier voulez-vous choisir (coco : 1 , lena : 2, res : 3, Entré votre propre fichier : 4) :  ");
            int image1 = Convert.ToInt32(Console.ReadLine());
            string dossier = "";
            if (image1 == 1)
            {
                dossier = "coco.bmp";
            }
            else if(image1 == 3)
            {
                dossier = "res.bmp";
            }
            else if (image1 == 4)
            {
                Console.Write("Entré le nom de votre fichier : ");
                dossier = Console.ReadLine();
            }
            else
            {
                dossier = "lena.bmp";
            }
            
            return dossier;
        }
        public static void Main(string[] args)
        {
            Affichermenu();
            int choix = int.Parse(Console.ReadLine());
            while (choix != 0)
            {
                
                switch (choix)
                {
                    case 0:
                        break;
                    case 1:
                        Myimage Image = new Myimage(ChoisirImage());
                        Image.NB();
                        Image.From_Image_To_File("res.bmp");
                        break;
                    case 2:
                        Image = new Myimage(ChoisirImage());
                        Image.Gris();
                        Image.From_Image_To_File("res.bmp");
                        break;
                    case 3:
                        Image = new Myimage(ChoisirImage());
                        Image.Miroir();
                        Image.From_Image_To_File("res.bmp");
                        break;
                    case 4:
                        Image = new Myimage(ChoisirImage());
                        Console.Write("Entrez le  d'agrendissement / rétrécissement : ");
                        Image.AgranRetre(Convert.ToDouble(Console.ReadLine()));
                        Image.From_Image_To_File("res.bmp");
                        break;
                    case 5:
                        Image = new Myimage(ChoisirImage());
                        Console.Write("Entrez un angle : ");
                        double angle = Convert.ToDouble(Console.ReadLine());
                        Image.Rotation(angle);
                        Image.From_Image_To_File("res.bmp");
                        break;
                    case 6:
                        Image = new Myimage(ChoisirImage());
                        Image.Flou();
                        Image.From_Image_To_File("res.bmp");
                        break;
                    case 7:
                        Image = new Myimage(ChoisirImage());
                        Console.WriteLine("Entrez le niveau de détection de contour (1,2,3,4) : ");
                        int y = Convert.ToInt32(Console.ReadLine());
                        Image.Detect(y);
                        Image.From_Image_To_File("res.bmp");
                        break;
                    case 8:
                        Image = new Myimage(ChoisirImage());
                        Image.Renfor();
                        Image.From_Image_To_File("res.bmp");
                        break;
                    case 9:
                        Image = new Myimage(ChoisirImage());
                        Image.Repoussage();
                        Image.From_Image_To_File("res.bmp");
                        break;
                    case 10:
                        Image = new Myimage("coco.bmp");
                        
                        Image.Fractale();
                        Image.From_Image_To_File("res.bmp");
                        break;
                    case 11:
                        Image = new Myimage(ChoisirImage());
                        Image.Histo();
                        Image.From_Image_To_File("res.bmp");
                        break;
                    case 12:
                        Image = new Myimage(ChoisirImage());
                        Image.Contrast();
                        Image.From_Image_To_File("res.bmp");
                        break;
                    case 13:
                        Console.Write("Entrez le message que vous voulez encodez :  ");

                        QRcode qr = new QRcode(Console.ReadLine());

                        break;
                    case 14:
                        Image = new Myimage(ChoisirImage());
                        Image.EncoderImage();
                        Image.From_Image_To_File("res.bmp");
                        break;
                    case 15:
                        Image = new Myimage(ChoisirImage());
                        Image.CacherImage(Image);

                        break;
                    case 16:
                        Image = new Myimage("res.bmp");
                        Image.AgranRetre(12.5);
                        Image.Rotation(180);
                        Image.Miroir();
                        qr = new QRcode(Image);
                        Console.ReadKey();
                        break;
                    case 17:
                        Image = new Myimage(ChoisirImage());
                        Image.FiltreSobel();
                        Image.From_Image_To_File("res.bmp");
                        break;
                    default:

                        break;
                }
                Process.Start("res.bmp");
                Console.Clear();
                Affichermenu();
                Console.WriteLine("Quel est votre prochain choix :  ");
                choix = int.Parse(Console.ReadLine());

            }
        }
    }
}
