﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_Info_S2
{
    /*class Form2
    {
        public partial class Form1 : Form
        {
            InitializeComponent();
        }



        private void button2_Click(object sender, EventArgs e)
        {
            BarcodeWriter barcodewriter = new BarcodeWriter();
            EncodingOptions enc = new EncodingOptions() { Width = 500, Height = 500, Margin = 0, PureBarcode = false };
            enc.Hints.Add(EncodeHintType.ERROR_CORRECTION, null);


            barcodewriter.Renderer = new BitmapRenderer();
            barcodewriter.Options = enc;
            barcodewriter.Format = BarcodeFormat.QR_CODE;

            Bitmap bitmap = barcodewriter.Write(textBox1.Text);
            //Bitmap logo = new Bitmap($"{Application.StartupPath}/logo_ESILV_en_couleur_petit.png");

            //Graphics g = Graphics.FromImage(bitmap);
            //g.DrawImage(logo, new Point((bitmap.Width - logo.Width) / 2, (bitmap.Height - logo.Height) / 2));

            pictureBox1.Image = bitmap;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            BarcodeReader barcodeReader = new BarcodeReader();
            var result = barcodeReader.Decode(new Bitmap(pictureBox1.Image));
            if (result != null) textBox2.Text = result.Text;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }*/
}
