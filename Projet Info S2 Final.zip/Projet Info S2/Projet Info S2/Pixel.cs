﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_Info_S2
{
    public class Pixel
    {
        ///Cette Classe permet de qualifié ce qu'est un Pixel et d'utilisé cette objet Pixel afin de facilité
        ///La manipulation d'une image
        
        private byte red;
        private byte green;
        private byte blue;
        public Pixel(byte rrr, byte ggg, byte bbb)
        {
            this.red = rrr;
            this.green = ggg;
            this.blue = bbb;
        }
        public Pixel(Pixel pix)
        {
            this.red = (byte)pix.R;
            this.green = (byte)pix.G;
            this.blue = (byte)pix.B;
        }
        public byte R
        {
            get { return red; }
            set { red = value; }
        }
        public byte G
        {
            get { return green; }
            set { green = value; }
        }
        public byte B
        {
            get { return blue; }
            set { blue = value; }
        }
        
    }

}
