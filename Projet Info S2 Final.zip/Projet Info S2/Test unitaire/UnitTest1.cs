using Microsoft.VisualStudio.TestTools.UnitTesting;
using Projet_Info_S2;
using System;
namespace Projet_Info_S2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestNB()
        {
            Myimage a = new Myimage("coco.bmp");
            Myimage ImageBW = new Myimage("TestBW.bmp");
            a.NB();
            Pixel[,] sortie = a.Matrice;
          
            for(int i = 0;i<sortie.GetLength(0);i++)
            {
                for(int j = 0;j<sortie.GetLength(1);j++)
                {
                    if (sortie[i,j].R != 0 && sortie[i,j].R != 255)
                    {
                        Assert.Fail(); //Pour dire que le test ne marche pas 
                        // On peut mettre diff�rents trucs avec le Assert genre Assert.Equal
                    }
                }
            }
        }
        [TestMethod]
        public void TestRotation180()
        {
            Myimage ImageSortie = new Myimage("res.bmp");
            Myimage Imagedebase = new Myimage("res.bmp");
            ImageSortie.Rotation(180);
            Pixel[,] sortie = ImageSortie.Matrice;
            Pixel[,] entre = Imagedebase.Matrice;
            if (sortie.GetLength(0) !=entre.GetLength(1) && sortie.GetLength(1) != entre.GetLength(0))
            {
                Assert.Fail();
            }
            for(int i = 0;i<sortie.GetLength(0);i++)
            {
                for(int j = 0;j<sortie.GetLength(1);j++)
                {
                    if(sortie[i,j] != entre[i,j])
                    {
                        Assert.Fail();
                    }
                }
            }
        }
        

    }
}
